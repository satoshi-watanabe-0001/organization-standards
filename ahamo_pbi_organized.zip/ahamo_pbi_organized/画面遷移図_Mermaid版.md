# ahamo 端末購入導線 - 画面遷移図（Mermaid版）

**作成日**: 2025-10-28  
**目的**: ahamo端末購入に関わる全画面の遷移フローをMermaid記法で可視化

---

## 📊 全体画面遷移フロー（統合版）

```mermaid
graph TD
    Start[トップページ] --> Products[製品タブ]
    Start --> Apply[申し込みボタン]
    
    Products --> CategoryTop[製品カテゴリトップページ<br/>PBI-DP-001]
    
    CategoryTop --> iPhone[iPhoneカテゴリ<br/>PBI-DP-002]
    CategoryTop --> Android[Androidカテゴリ<br/>PBI-DP-003]
    CategoryTop --> Reuse[リユース品カテゴリ<br/>PBI-DP-004]
    CategoryTop --> Accessory[アクセサリカテゴリ<br/>PBI-DP-010]
    
    iPhone --> Detail[機種詳細ページ<br/>PBI-DP-005]
    Android --> Detail
    Reuse --> Detail
    
    Detail --> Campaign1[5G WELCOME割<br/>PBI-DP-006-1]
    Detail --> Campaign2[カエドキプログラム<br/>PBI-DP-006-2]
    Detail --> Payment[支払い方法情報<br/>PBI-DP-007]
    Detail --> FAQ[FAQ・サポート<br/>PBI-DP-011]
    
    Detail --> NewPurchase{顧客タイプ}
    NewPurchase -->|新規/MNP| ApplyFlow[新規契約フロー<br/>PBI-DP-008]
    NewPurchase -->|既存顧客| ChangeFlow[機種変更フロー<br/>PBI-DP-009]
    
    ApplyFlow --> Identity[本人確認<br/>PBI-DP-012]
    Identity --> Shipping[配送状況確認<br/>PBI-DP-013]
    
    ChangeFlow --> External[ドコモオンライン<br/>ショップ<br/>外部サイト]
    External --> Return[端末返却プログラム<br/>PBI-DP-014]
    
    Accessory --> AccessoryPurchase[アクセサリ購入完了]
    
    style Start fill:#e1f5ff
    style CategoryTop fill:#fff4e1
    style Detail fill:#ffe1f5
    style ApplyFlow fill:#e1ffe1
    style ChangeFlow fill:#ffe1e1
    style External fill:#f0f0f0
```

---

## 1️⃣ 製品閲覧導線（情報収集フロー）

### 基本フロー

```mermaid
flowchart TD
    A[トップページ] -->|製品タブクリック| B[製品カテゴリトップページ<br/>PBI-DP-001]
    
    B -->|カテゴリ選択| C1[iPhoneカテゴリ<br/>PBI-DP-002]
    B -->|カテゴリ選択| C2[Androidカテゴリ<br/>PBI-DP-003]
    B -->|カテゴリ選択| C3[リユース品カテゴリ<br/>PBI-DP-004]
    B -->|カテゴリ選択| C4[アクセサリカテゴリ<br/>PBI-DP-010]
    
    C1 -->|機種選択| D[機種詳細ページ<br/>PBI-DP-005]
    C2 -->|機種選択| D
    C3 -->|機種選択| D
    
    D --> E1[カラー選択]
    D --> E2[容量選択]
    D --> E3[価格確認]
    
    E3 --> F1[支払い方法情報<br/>PBI-DP-007]
    E3 --> F2[5G WELCOME割<br/>PBI-DP-006-1]
    E3 --> F3[カエドキプログラム<br/>PBI-DP-006-2]
    
    D --> G[スペック情報確認]
    D --> H[FAQ・サポート情報<br/>PBI-DP-011]
    
    style A fill:#e1f5ff
    style B fill:#fff4e1
    style D fill:#ffe1f5
    style F1 fill:#e1ffe1
    style F2 fill:#e1ffe1
    style F3 fill:#e1ffe1
```

### サポート情報への遷移

```mermaid
graph LR
    A[機種詳細ページ表示中] --> B[FAQ・サポート情報<br/>PBI-DP-011]
    A --> C[本人確認要件の確認<br/>PBI-DP-012]
    
    B --> B1[端末購入FAQ]
    B --> B2[配送情報]
    B --> B3[開通方法]
    B --> B4[返品ポリシー]
    
    C --> C1[必要書類の案内]
    C --> C2[提出方法]
    
    style A fill:#ffe1f5
    style B fill:#e1f5ff
    style C fill:#e1f5ff
```

---

## 2️⃣ 新規契約・MNP導線（新規顧客の購入フロー）

```mermaid
flowchart TD
    A[製品詳細ページ または トップページ] -->|申し込みボタン| B[申込みフロー開始<br/>PBI-DP-008]
    
    B --> C{契約種別の選択}
    C -->|選択| D1[新規契約]
    C -->|選択| D2[他社からのりかえ MNP]
    C -->|選択| D3[ドコモからプラン変更]
    
    D1 --> E{SIM・端末選択}
    D2 --> E
    D3 --> E
    
    E -->|選択| F1[SIMのみ]
    E -->|選択| F2[SIM + 端末]
    
    F2 --> G[端末選択画面]
    
    G --> H1[カテゴリ選択]
    G --> H2[機種選択]
    G --> H3[カラー選択]
    G --> H4[容量選択]
    G --> H5[支払い方法選択<br/>一括/分割]
    
    H1 --> I[配送情報・開通情報の表示]
    H2 --> I
    H3 --> I
    H4 --> I
    H5 --> I
    
    I --> J[配送期間: 最短4日<br/>開通時間: 9:00-21:00]
    
    J --> K[本人確認書類の提出<br/>PBI-DP-012]
    
    K --> L[申込み完了]
    
    L --> M1[注文番号発行]
    L --> M2[確認メール送信]
    
    M1 --> N[マイページ - 配送状況確認<br/>PBI-DP-013]
    M2 --> N
    
    N --> O1[商品準備中]
    N --> O2[発送済み 追跡番号付]
    N --> O3[配達中]
    N --> O4[配達完了]
    
    style A fill:#e1f5ff
    style B fill:#fff4e1
    style G fill:#ffe1f5
    style K fill:#e1ffe1
    style N fill:#f5e1ff
```

### 新規購入フロー（簡略版）

```mermaid
sequenceDiagram
    participant U as 顧客
    participant T as トップページ
    participant A as 申込みフロー
    participant D as 端末選択
    participant I as 本人確認
    participant M as マイページ
    
    U->>T: 申し込みボタンクリック
    T->>A: 契約種別選択画面表示
    U->>A: 新規契約・SIM+端末選択
    A->>D: 端末選択画面表示
    U->>D: 機種・カラー・容量選択
    D->>I: 本人確認画面表示
    U->>I: 書類提出
    I->>M: 申込み完了・配送状況確認
    Note over M: 最短4日で配送
```

---

## 3️⃣ 機種変更導線（既存顧客の購入フロー）

```mermaid
flowchart TD
    A[ahamoサイト ログイン済み] --> B[製品ページ]
    
    B --> C[カテゴリトップ or 機種詳細]
    
    C --> D[機種を選択]
    C --> E[カラー・容量を確認]
    
    D --> F[購入するボタン]
    E --> F
    
    F --> G[遷移確認画面<br/>PBI-DP-009]
    
    G --> H[⚠️ ドコモオンラインショップに<br/>遷移します]
    
    H --> I[✓ ahamo契約は継続利用可能]
    
    I --> J[OKボタン]
    
    J -->|外部サイトへ遷移| K[ドコモオンラインショップ<br/>機種変更ページ]
    
    K --> L1[カラーを選ぶ]
    K --> L2[容量を選ぶ]
    K --> L3[購入方法を選ぶ]
    
    L3 --> M[機種変更を選択]
    
    M --> N[パスキー認証]
    
    N --> O1[dアカウントログイン]
    N --> O2[パスキー認証実行]
    
    O1 --> P[購入手続き完了]
    O2 --> P
    
    P --> Q1[商品発送の案内]
    P --> Q2[開通手続き方法の案内]
    
    Q1 --> R[商品到着後]
    Q2 --> R
    
    R --> S[ahamoアプリで開通手続き]
    
    S --> T[利用開始]
    
    T -.->|オプション| U[端末返却プログラム<br/>PBI-DP-014]
    
    style A fill:#e1f5ff
    style G fill:#fff4e1
    style K fill:#f0f0f0
    style N fill:#ffe1e1
    style U fill:#e1ffe1
```

### 機種変更フロー（簡略版）

```mermaid
sequenceDiagram
    participant U as 既存顧客
    participant A as ahamoサイト
    participant C as 確認画面
    participant D as ドコモOS
    participant P as パスキー認証
    participant M as ahamoアプリ
    
    U->>A: ログイン
    U->>A: 製品ページで機種選択
    A->>C: 遷移確認画面表示
    Note over C: ドコモオンラインショップへ遷移<br/>ahamo契約は継続
    U->>C: OK
    C->>D: 外部サイトへ遷移
    U->>D: 機種・カラー・容量選択
    D->>P: パスキー認証要求
    U->>P: dアカウント認証
    P->>D: 認証成功
    U->>D: 購入完了
    Note over D: 商品発送
    D->>M: 開通手続き案内
    U->>M: 開通手続き実行
    Note over M: 利用開始
```

---

## 🎯 画面遷移パターン（状態遷移図）

### パターン1: 情報閲覧の状態遷移

```mermaid
stateDiagram-v2
    [*] --> トップページ
    トップページ --> 製品カテゴリトップ: 製品タブ
    
    製品カテゴリトップ --> iPhoneカテゴリ: カテゴリ選択
    製品カテゴリトップ --> Androidカテゴリ: カテゴリ選択
    製品カテゴリトップ --> リユース品カテゴリ: カテゴリ選択
    製品カテゴリトップ --> アクセサリカテゴリ: カテゴリ選択
    
    iPhoneカテゴリ --> 機種詳細: 機種選択
    Androidカテゴリ --> 機種詳細: 機種選択
    リユース品カテゴリ --> 機種詳細: 機種選択
    
    機種詳細 --> 5G_WELCOME割: 情報参照
    機種詳細 --> カエドキプログラム: 情報参照
    機種詳細 --> 支払い方法情報: 情報参照
    機種詳細 --> FAQサポート: 情報参照
    
    機種詳細 --> [*]: 購入決定へ
```

### パターン2: 新規購入フローの状態遷移

```mermaid
stateDiagram-v2
    [*] --> 申込み開始
    申込み開始 --> 契約種別選択: フロー開始
    
    契約種別選択 --> SIM端末選択: 種別決定
    
    SIM端末選択 --> SIMのみ: 選択
    SIM端末選択 --> SIM端末セット: 選択
    
    SIM端末セット --> 端末選択: 端末購入
    
    端末選択 --> カテゴリ選択: ステップ1
    カテゴリ選択 --> 機種選択: ステップ2
    機種選択 --> カラー選択: ステップ3
    カラー選択 --> 容量選択: ステップ4
    容量選択 --> 支払い方法選択: ステップ5
    
    支払い方法選択 --> 配送情報表示: 確認
    
    配送情報表示 --> 本人確認: 次へ
    
    本人確認 --> 書類提出: 提出
    
    書類提出 --> 申込み完了: 完了
    
    申込み完了 --> 配送状況確認: マイページ
    
    配送状況確認 --> [*]: 商品到着
```

### パターン3: 機種変更フローの状態遷移

```mermaid
stateDiagram-v2
    [*] --> ログイン済み
    ログイン済み --> 製品ページ: 製品閲覧
    
    製品ページ --> 機種選択: 機種決定
    
    機種選択 --> 遷移確認: 購入ボタン
    
    遷移確認 --> ドコモOS遷移: OK
    
    state ドコモオンラインショップ {
        [*] --> 機種オプション選択
        機種オプション選択 --> パスキー認証
        パスキー認証 --> 購入完了
        購入完了 --> [*]
    }
    
    ドコモOS遷移 --> ドコモオンラインショップ: 外部遷移
    
    ドコモオンラインショップ --> 商品発送: 購入完了
    
    商品発送 --> 開通手続き: 商品到着
    
    開通手続き --> 利用開始: 完了
    
    利用開始 --> [*]
    
    利用開始 --> 端末返却: オプション
```

---

## 🔄 主要な依存関係（クラス図）

```mermaid
classDiagram
    class 製品カテゴリトップ {
        +PBI-DP-001
        +表示()
        +カテゴリ選択()
    }
    
    class iPhoneカテゴリ {
        +PBI-DP-002
        +一覧表示()
        +機種選択()
    }
    
    class Androidカテゴリ {
        +PBI-DP-003
        +一覧表示()
        +機種選択()
    }
    
    class リユース品カテゴリ {
        +PBI-DP-004
        +一覧表示()
        +機種選択()
    }
    
    class 機種詳細 {
        +PBI-DP-005
        +詳細表示()
        +カラー選択()
        +容量選択()
    }
    
    class キャンペーン情報 {
        +PBI-DP-006-1
        +PBI-DP-006-2
        +5G_WELCOME割()
        +カエドキプログラム()
    }
    
    class 支払い方法情報 {
        +PBI-DP-007
        +一括払い()
        +分割払い()
        +シミュレーション()
    }
    
    class 新規契約フロー {
        +PBI-DP-008
        +契約種別選択()
        +端末選択()
        +申込み()
    }
    
    class 機種変更フロー {
        +PBI-DP-009
        +外部遷移()
        +認証()
        +購入()
    }
    
    class 本人確認 {
        +PBI-DP-012
        +書類提出()
        +確認()
    }
    
    class 配送状況確認 {
        +PBI-DP-013
        +追跡()
        +ステータス確認()
    }
    
    製品カテゴリトップ --> iPhoneカテゴリ : 遷移
    製品カテゴリトップ --> Androidカテゴリ : 遷移
    製品カテゴリトップ --> リユース品カテゴリ : 遷移
    
    iPhoneカテゴリ --> 機種詳細 : 遷移
    Androidカテゴリ --> 機種詳細 : 遷移
    リユース品カテゴリ --> 機種詳細 : 遷移
    
    機種詳細 --> キャンペーン情報 : 参照
    機種詳細 --> 支払い方法情報 : 参照
    
    機種詳細 --> 新規契約フロー : 新規購入
    機種詳細 --> 機種変更フロー : 機種変更
    
    新規契約フロー --> 本人確認 : 必須
    新規契約フロー --> 配送状況確認 : 完了後
```

---

## 📱 画面タイプ別の関係図

```mermaid
graph TB
    subgraph 情報表示画面
        A1[製品カテゴリトップ DP-001]
        A2[iPhoneカテゴリ DP-002]
        A3[Androidカテゴリ DP-003]
        A4[リユース品カテゴリ DP-004]
        A5[機種詳細 DP-005]
        A6[5G WELCOME割 DP-006-1]
        A7[カエドキプログラム DP-006-2]
        A8[支払い方法情報 DP-007]
        A9[FAQ・サポート DP-011]
        A10[本人確認要件 DP-012]
    end
    
    subgraph フロー画面
        B1[新規契約フロー DP-008]
        B2[機種変更フロー DP-009]
        B3[アクセサリ購入 DP-010]
    end
    
    subgraph ステータス確認画面
        C1[配送状況確認 DP-013]
        C2[端末返却プログラム DP-014]
    end
    
    A1 --> A2
    A1 --> A3
    A1 --> A4
    A2 --> A5
    A3 --> A5
    A4 --> A5
    A5 --> A6
    A5 --> A7
    A5 --> A8
    A5 --> A9
    
    A5 --> B1
    A5 --> B2
    
    B1 --> A10
    B1 --> C1
    B2 --> C2
    
    style A1 fill:#fff4e1
    style A5 fill:#ffe1f5
    style B1 fill:#e1ffe1
    style B2 fill:#ffe1e1
    style C1 fill:#f5e1ff
```

---

## 🚪 外部サイトへの遷移フロー

```mermaid
flowchart LR
    subgraph ahamoサイト
        A[機種詳細ページ]
        B[遷移確認画面]
    end
    
    subgraph 確認事項
        C1[ahamo契約継続を明示]
        C2[外部サイト移動を通知]
        C3[認証情報を案内]
    end
    
    subgraph ドコモオンラインショップ
        D[機種変更ページ]
        E[パスキー認証]
        F[購入完了]
    end
    
    A --> B
    B --> C1
    B --> C2
    B --> C3
    C1 --> D
    C2 --> D
    C3 --> D
    D --> E
    E --> F
    
    style A fill:#e1f5ff
    style B fill:#fff4e1
    style D fill:#f0f0f0
    style E fill:#ffe1e1
```

---

## 🎨 全体アーキテクチャ（簡略版）

```mermaid
graph TD
    subgraph 情報収集段階
        Top[トップページ]
        Cat[製品カテゴリ]
        Det[機種詳細]
    end
    
    subgraph 購入判断段階
        Camp[キャンペーン情報]
        Pay[支払い情報]
        FAQ[FAQ・サポート]
    end
    
    subgraph 購入実行段階_新規
        New[新規契約フロー]
        ID[本人確認]
        Ship[配送状況]
    end
    
    subgraph 購入実行段階_既存
        Change[機種変更フロー]
        Docomo[ドコモOS]
        Return[端末返却]
    end
    
    Top --> Cat
    Cat --> Det
    Det --> Camp
    Det --> Pay
    Det --> FAQ
    
    Det --> New
    Det --> Change
    
    New --> ID
    ID --> Ship
    
    Change --> Docomo
    Docomo --> Return
    
    style Top fill:#e1f5ff
    style Det fill:#ffe1f5
    style New fill:#e1ffe1
    style Change fill:#ffe1e1
    style Docomo fill:#f0f0f0
```

---

## 📊 画面数とPBI対応（ER図的表現）

```mermaid
erDiagram
    製品閲覧系 ||--o{ 製品カテゴリトップ : "1画面"
    製品閲覧系 ||--o{ iPhoneカテゴリ : "1画面"
    製品閲覧系 ||--o{ Androidカテゴリ : "1画面"
    製品閲覧系 ||--o{ リユース品カテゴリ : "1画面"
    製品閲覧系 ||--o{ 機種詳細 : "1画面"
    製品閲覧系 ||--o{ 支払い方法情報 : "1画面"
    製品閲覧系 ||--o{ アクセサリカテゴリ : "1画面"
    
    キャンペーン系 ||--o{ 5G_WELCOME割 : "1画面"
    キャンペーン系 ||--o{ カエドキプログラム : "1画面"
    
    申込み購入系 ||--o{ 新規契約フロー : "1画面"
    申込み購入系 ||--o{ 本人確認 : "1画面"
    
    サポート系 ||--o{ FAQサポート : "1画面"
    
    マイページ系 ||--o{ 配送状況確認 : "1画面"
    
    機種変更系 ||--o{ 機種変更フロー : "1画面"
    機種変更系 ||--o{ 端末返却プログラム : "1画面"
    
    製品閲覧系 {
        int 画面数 "7"
        int Story_Points "54"
    }
    
    キャンペーン系 {
        int 画面数 "2"
        int Story_Points "8"
    }
    
    申込み購入系 {
        int 画面数 "2"
        int Story_Points "18"
    }
    
    機種変更系 {
        int 画面数 "2"
        int Story_Points "21"
    }
```

---

## 💡 Mermaid図の表示方法

### GitHub / GitLab
Markdownファイルに直接Mermaid記法を記述すれば自動レンダリングされます。

### VS Code
以下の拡張機能をインストール:
- **Markdown Preview Mermaid Support**
- **Mermaid Markdown Syntax Highlighting**

### オンラインエディタ
- [Mermaid Live Editor](https://mermaid.live/)
- [Mermaid Chart](https://www.mermaidchart.com/)

### Notion / Confluence
一部のツールではMermaid記法をサポートしていないため、PNG画像として出力して貼り付けてください。

---

## 🎯 図の種類と用途

| 図の種類 | 用途 | 該当セクション |
|---------|-----|--------------|
| **flowchart** | 画面遷移の流れを表現 | 1️⃣2️⃣3️⃣導線 |
| **sequenceDiagram** | 時系列の相互作用を表現 | 購入フロー簡略版 |
| **stateDiagram** | 状態遷移を表現 | 状態遷移パターン |
| **classDiagram** | 画面間の依存関係を表現 | 依存関係 |
| **graph** | 全体構造を表現 | 全体アーキテクチャ |
| **erDiagram** | データ構造的な関係を表現 | 画面数とPBI対応 |

---

## 🔗 関連ドキュメント

- [画面遷移図.md](./画面遷移図.md) - テキストベースの詳細版
- [README.md](./README.md) - 全体構成と使い方
- [PBI整理サマリー.md](./PBI整理サマリー.md) - 優先度と活用方法

---

**Document Version**: 1.0  
**Last Updated**: 2025-10-28  
**作成者**: AI Assistant
